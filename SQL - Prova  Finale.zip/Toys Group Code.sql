
CREATE SCHEMA ToysGroup;

USE ToysGroup;


-- CREAZIONE TABELLE CON PK E FK --

CREATE TABLE Category (
    CategoryID INT NOT NULL,
    CategoryName VARCHAR(255),
    CONSTRAINT PK_Category PRIMARY KEY (CategoryID)
);

CREATE TABLE Region (
    RegionID INT NOT NULL,
    RegionName VARCHAR(255),
    CONSTRAINT PK_Region PRIMARY KEY (RegionID)
);

CREATE TABLE State (
    StateID INT NOT NULL,
    StateName VARCHAR(255),
    RegionID INT NOT NULL,
    CONSTRAINT PK_State PRIMARY KEY (StateID),
    CONSTRAINT FK_State_Region FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);

CREATE TABLE Product (
    ProductID INT NOT NULL,
    ProductName VARCHAR(255),
    CategoryID INT NOT NULL,
    PriceUnit DECIMAL (10,2),
    CONSTRAINT PK_Product PRIMARY KEY (ProductID),
    CONSTRAINT FK_Product_Category FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID)
);

CREATE TABLE Sales (
    OrderID INT NOT NULL,
    OrderDate DATE NOT NULL,
    ProductID INT NOT NULL,
    StateID INT NULL,
    Quantity INT NOT NULL,
    CONSTRAINT PK_Sales PRIMARY KEY (OrderID),
    CONSTRAINT FK_Sales_Product FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    CONSTRAINT FK_Sales_State FOREIGN KEY (StateID) REFERENCES State(StateID)
);


-- POPOLAZIONE TABELLE , INSERT INTO

-- Popolamento CATEGORY
INSERT INTO Category VALUES (1, 'Bikes'),	
	(2,'Puzzle'),	
	(3, 'Peluche');

-- Popolamento PRODUCT
INSERT INTO Product VALUES (1, 'Bike 100', 1, 175.00),
	(2, 'Bike 200', 1, 188.00),
	(3, 'Tour Eiffel Puzzle', 2, 22.00),
	(4, 'Colosseum Puzzle', 2, 24.00),
	(5, 'Simba', 3, 17.00),
	(6, 'Toy Story Puzzle', 2, 22.00),
	(7, 'Teddy Bear', 3, 11.00),
	(8, 'Dumbo', 3, 19.00),
	(9, 'Bike 700', 1, 175.00),
	(10, 'Aladin', 3, 15.00);

-- Popolamento REGION
INSERT INTO Region VALUES (1, 'WestEurope'), 
(2, 'SouthEurope'), 
(3, 'NorthEurope');

-- Popolamento STATE
INSERT INTO State VALUES (1, 'Italy', 2), 
(2, 'Germany', 1), 
(3, 'France', 1), 
(4, 'Finland', 3), 
(5, 'Sweden', 3), 
(6, 'Poland', 1), 
(7, 'Denmark', 3);

-- Popolamento SALES
INSERT INTO Sales VALUES (1, '2024-01-04', 5, 1, 10),
(2, '2024-02-14', 2, 4, 7),
(3, '2024-03-22', 1, 3, 2),
(4, '2024-01-18', 8, 1, 4),
(5, '2024-03-30', 4, 5, 1),
(6, '2024-01-11', 6, 2, 9),
(7, '2024-02-28', 3, 6, 8),
(8, '2024-03-15', 7, 7, 3),
(9, '2024-01-23', 2, 5, 6),
(10, '2024-02-09', 1, 2, 10),
(11, '2024-03-03', 8, 1, 5),
(12, '2024-01-15', 4, 4, 7),
(13, '2024-02-19', 5, 3, 2),
(14, '2024-03-21', 3, 2, 4),
(15, '2024-01-08', 7, 5, 1),
(16, '2024-02-23', 6, 7, 9),
(17, '2024-03-29', 2, 6, 8),
(18, '2024-01-02', 1, 1, 3),
(19, '2024-02-12', 8, 4, 6),
(20, '2024-03-17', 4, 2, 10),
(21, '2024-01-19', 5, 3, 5),
(22, '2024-02-27', 3, 1, 7),
(23, '2024-03-10', 7, 6, 2),
(24, '2024-01-07', 6, 7, 4),
(25, '2024-02-16', 2, 5, 6),
(26, '2024-03-01', 1, 4, 10),
(27, '2024-01-25', 8, 3, 3),
(28, '2024-02-03', 4, 2, 7),
(29, '2024-03-12', 3, 1, 2),
(30, '2024-01-13', 7, 5, 1),
(31, '2024-10-01', 1, 1, 5),
(32, '2024-10-02', 2, 2, 6),
(33, '2024-10-03', 3, 3, 7),
(34, '2024-10-04', 4, 4, 8),
(35, '2024-10-05', 5, 5, 2),
(36, '2024-10-06', 6, 6, 3),
(37, '2024-10-07', 7, 7, 4),
(38, '2024-10-08', 8, 1, 5),
(39, '2024-10-09', 1, 2, 6),
(40, '2024-10-10', 2, 3, 7),
(41, '2024-10-11', 3, 4, 8),
(42, '2024-10-12', 4, 5, 2),
(43, '2024-10-13', 5, 6, 3),
(44, '2024-10-14', 6, 7, 4),
(45, '2024-10-15', 7, 1, 5),
(46, '2024-10-16', 8, 2, 6),
(47, '2024-10-17', 1, 3, 7),
(48, '2024-10-18', 2, 4, 8),
(49, '2024-10-19', 3, 5, 2),
(50, '2024-10-20', 4, 6, 3),
(51, '2024-10-21', 5, 7, 4),
(52, '2024-10-22', 6, 1, 5),
(53, '2024-10-23', 7, 2, 6),
(54, '2024-10-24', 8, 3, 7),
(55, '2024-10-25', 1, 4, 8),
(56, '2024-10-26', 2, 5, 2),
(57, '2024-10-27', 3, 6, 3),
(58, '2024-10-28', 4, 7, 4),
(59, '2024-10-29', 5, 1, 5),
(60, '2024-10-30', 6, 2, 6),
(61, '2024-01-15', 8, 1, 4),
(62, '2024-02-23', 1, 2, 6),
(63, '2024-03-10', 2, 3, 7),
(64, '2024-04-05', 3, 4, 2),
(65, '2024-05-20', 4, 5, 3),
(66, '2024-06-25', 5, 6, 4),
(67, '2024-07-13', 6, 7, 5),
(68, '2024-08-22', 7, 1, 6),
(69, '2024-09-16', 8, 2, 7),
(70, '2024-10-04', 1, 3, 8),
(71, '2024-11-12', 2, 4, 9),
(72, '2024-12-21', 3, 5, 10),
(73, '2024-01-26', 4, 6, 3),
(74, '2024-02-28', 5, 7, 4),
(75, '2024-03-18', 6, 1, 5),
(76, '2024-04-07', 7, 2, 6),
(77, '2024-05-16', 8, 3, 7),
(78, '2024-06-05', 1, 4, 8),
(79, '2024-07-24', 2, 5, 9),
(80, '2024-08-13', 3, 6, 10),
(81, '2024-09-02', 4, 7, 3),
(82, '2024-10-11', 5, 1, 4),
(83, '2024-11-20', 6, 2, 5),
(84, '2024-12-09', 7, 3, 6),
(85, '2024-01-03', 8, 4, 7),
(86, '2024-02-12', 1, 5, 8),
(87, '2024-03-23', 2, 6, 9),
(88, '2024-04-01', 3, 7, 10),
(89, '2024-05-10', 4, 1, 3),
(90, '2024-06-19', 5, 2, 4),
(91, '2024-07-08', 6, 3, 5),
(92, '2024-08-17', 7, 4, 6),
(93, '2024-09-06', 8, 5, 7),
(94, '2024-10-15', 1, 6, 8),
(95, '2024-11-24', 2, 7, 9),
(96, '2024-12-13', 3, 1, 10),
(97, '2024-01-22', 4, 2, 3),
(98, '2024-02-01', 5, 3, 4),
(99, '2024-03-12', 6, 4, 5),
(100, '2024-04-21', 7, 5, 6),
(101, '2023-01-15', 5, 1, 7),
(102, '2023-02-20', 3, 2, 4),
(103, '2023-03-12', 8, 3, 1),
(104, '2023-04-18', 1, 4, 9),
(105, '2023-05-23', 2, 5, 5),
(106, '2023-06-11', 7, 6, 2),
(107, '2023-07-07', 4, 7, 6),
(108, '2023-08-09', 6, 1, 3),
(109, '2023-09-05', 1, 2, 8),
(110, '2023-10-13', 2, 3, 7),
(111, '2023-11-21', 3, 4, 5),
(112, '2023-12-28', 4, 5, 4),
(113, '2023-01-22', 5, 6, 6),
(114, '2023-02-18', 6, 7, 1),
(115, '2023-03-25', 7, 1, 5),
(116, '2023-04-20', 8, 2, 8),
(117, '2023-05-16', 1, 3, 2),
(118, '2023-06-24', 2, 4, 9),
(119, '2023-07-12', 3, 5, 6),
(120, '2023-08-19', 4, 6, 3),
(121, '2023-09-27', 5, 7, 4),
(122, '2023-10-14', 6, 1, 7),
(123, '2023-11-03', 7, 2, 2),
(124, '2023-12-11', 8, 3, 1),
(125, '2023-01-29', 1, 4, 5),
(126, '2023-02-16', 2, 5, 8),
(127, '2023-03-20', 3, 6, 4),
(128, '2023-04-28', 4, 7, 9),
(129, '2023-05-15', 5, 1, 3),
(130, '2023-06-22', 6, 2, 2);


--  Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per determinare l’univocità dei valori di ciascuna PK (una query per tabella implementata). 

--  tabella Category
SELECT CategoryID, COUNT(*) as occurrences
FROM Category
GROUP BY CategoryID
HAVING COUNT(*) > 1;

-- tabella Product
SELECT ProductID, COUNT(*) as occurrences
FROM Product
GROUP BY ProductID
HAVING COUNT(*) > 1;

-- tabella Region
SELECT RegionID, COUNT(*) as occurrences
FROM Region
GROUP BY RegionID
HAVING COUNT(*) > 1;

-- tabella State
SELECT StateID, COUNT(*) as occurrences
FROM State
GROUP BY StateID
HAVING COUNT(*) > 1;

-- tabella Sales
SELECT OrderID, COUNT(*) as occurrences
FROM Sales
GROUP BY OrderID
HAVING COUNT(*) > 1;


-- Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto, il nome dello stato, il nome della regione di vendita 	
-- e un campo booleano valorizzato in base alla condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False) 

SELECT 
    OrderID,
    OrderDate,
    ProductName,
    CategoryName,
    StateName,
    RegionName,
    CASE 
        WHEN DATEDIFF(CURDATE(), OrderDate) > 180 THEN 'True' 
        ELSE 'False' 
    END AS 'Older Than 180days'
FROM 
    Sales
JOIN 
    Product ON sales.ProductID = product.ProductID
JOIN 
    Category ON product.CategoryID = category.CategoryID
JOIN 
    State ON state.StateID = state.StateID
JOIN 
    Region ON state.RegionID = region.RegionID;
    
-- Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate nell’ultimo anno censito. 
-- (ogni valore della condizione deve risultare da una query e non deve essere inserito a mano). Nel result set devono comparire solo il codice prodotto e il totale venduto. 

-- Prima calcolo il totale venduto con Group BY per il Product ID, poi nella Query vado a innestarne un'altra per metterlo a confronto con la media del 2023)

SELECT 
    ProductID ,
    SUM(Quantity) AS '2023 Sales vs AVG 2023'
FROM 
    Sales
WHERE 
    YEAR(OrderDate) = YEAR(CURDATE()) - 1  
GROUP BY 
    ProductID 
HAVING 
    SUM(Quantity) > (SELECT AVG(TotalQuantity) 	
						FROM (
                        SELECT 
                            SUM(Quantity) AS TotalQuantity
                        FROM 
                            Sales
                        WHERE 
                            YEAR(OrderDate) = YEAR(CURDATE()) - 1
                        GROUP BY 
                            ProductID
                     ) AS SubQuery)
                     
-- Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.

SELECT
YEAR(OrderDate) AS YEAR,
sales.ProductID AS ProductID,
SUM(Quantity*PriceUnit) AS Revenue

FROM sales
JOIN Product ON sales.ProductID=Product.ProductID

GROUP BY 
sales.ProductID,YEAR(OrderDate);



-- Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.

SELECT
YEAR(OrderDate) AS YEAR,
state.stateID AS StateID,
statename AS STATE,
SUM(Quantity*PriceUnit) AS Revenue

FROM sales
JOIN Product ON sales.ProductID=Product.ProductID
JOIN State ON sales.StateID=state.stateID
GROUP BY 
state.stateID,YEAR(OrderDate)
ORDER BY YEAR(OrderDate), 'Revenue' DESC;

-- Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 
-- Query in cui calcolo la somma totale delle vendite per categoria e ordinando in maniera decrescente i risultati, chiedo di visualizzare solo il primo risultato.
SELECT 
    category.CategoryID,
    category.CategoryName,
    SUM(sales.Quantity) AS 'TOTAL SELLS'
FROM 
    sales
JOIN 
    product ON sales.ProductID = product.ProductID
JOIN 
    category ON product.CategoryID = category.CategoryID
GROUP BY 
    category.CategoryID, category.CategoryName
ORDER BY 
    SUM(sales.Quantity) DESC
LIMIT 1;

-- Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti. 

-- 1 APPROCCIO: LEFT JOIN TRA PRODUCT E SALES. COSì DA VEDERE QUALI PROSITTI NON HANNO QUANTITY IN SALES

SELECT
PRODUCT.PRODUCTID AS PRODUCTID,
PRODUCTNAME
FROM PRODUCT
LEFT JOIN SALES ON PRODUCT.PRODUCTID=SALES.PRODUCTID
WHERE SALES.ORDERID is null;

-- 2 APPROCCIO: UTILIZZO DI "NOT IN"

SELECT 
    ProductID,
    ProductName
FROM 
    Product
WHERE 
    ProductID NOT IN (SELECT ProductID FROM Sales);
    
    
-- Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni utili (codice prodotto, nome prodotto, nome categoria) 

CREATE VIEW ProductRecap AS
SELECT 
    product.ProductID AS 'Product ID',
    product.ProductName AS 'Product Name',
    category.CategoryName AS 'Category Name'
FROM 
    Product 
JOIN 
    Category  ON product.CategoryID = category.CategoryID;
    
    
    
-- Creare una vista per le informazioni geografiche


    
CREATE VIEW GeographicInfo AS
SELECT 
    state.StateID AS 'State ID',
    state.StateName AS 'State Name',
    region.RegionID AS 'Region ID',
    region.RegionName AS 'Region Name'
FROM 
    State
JOIN 
    Region ON state.RegionID = region.RegionID;